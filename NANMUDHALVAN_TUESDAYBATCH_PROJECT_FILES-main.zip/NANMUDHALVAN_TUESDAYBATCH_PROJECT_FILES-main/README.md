# NANMUDHALVAN_TUESDAYBATCH_PROJECT_FILES

PROJECT CREATED BY :SRIDHAR M  
6235,AVS COLLEGE OF TECHNOLOGY


LOGIN DETAILS:


UNAME: sridhar


Password:sri12345




#Project Running steps:

python manage.py makemigrations

python manage.py migrate

python manage.py createsuperuser

python manage.py runserver
